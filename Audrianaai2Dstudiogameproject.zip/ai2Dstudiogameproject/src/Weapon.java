public class Weapon extends Item {
    private int damage;
    private double chanceToHit; // Value between 0.0 and 1.0

    public Weapon(String name, String description, int damage, double chanceToHit) {
        super(name, description, true); // Weapons are typically obtainable
        this.damage = damage;
        this.chanceToHit = Math.max(0.0, Math.min(1.0, chanceToHit)); // Clamp between 0 and 1
    }

    public int getDamage() {
        return damage;
    }

    public double getChanceToHit() {
        return chanceToHit;
    }

    @Override
    public void use() {
        // Weapons aren't "used" directly, they are "equipped"
        System.out.println("Try equipping this weapon using 'equip " + getName() + "'.");
    }
}