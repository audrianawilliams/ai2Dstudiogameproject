public enum NPCStatus {
    FRIENDLY,
    HOSTILE
}