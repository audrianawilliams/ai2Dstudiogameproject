import java.util.Random;

public class NPC extends Player { // Inherits name, description, hp, inventory, etc.
    private NPCStatus status;
    private String dialogue;
    // Inherits equippedWeapon from Player, can be set in constructor
    private static final Random random = new Random(); // For attack rolls


    public NPC(String name, String description, int initialHp, NPCStatus status, String dialogue, Weapon weapon) {
        super(name, description, initialHp); // Call Player constructor
        this.status = status;
        this.dialogue = dialogue;
        if (weapon != null) {
            this.equipWeapon(weapon); // Equip the specific weapon
        }
        // If no weapon provided, Player constructor already gives "Fists"
    }

    // --- NPC Specific Methods ---
    public NPCStatus getStatus() {
        return status;
    }

    public boolean isHostile() {
        return status == NPCStatus.HOSTILE;
    }

    public String getDialogue() {
        return dialogue;
    }

    public void talk() {
        System.out.println(getName() + " says: \"" + dialogue + "\"");
        if (!isHostile() && getName().equalsIgnoreCase("Janitor")) { // Example hint
            System.out.println(getName() + " adds: \"Careful down those stairs... heard strange noises.\"");
        }
    }

    // --- Combat Methods ---
    public void attack(Player target) {
        if (getHp() <= 0) return; // Cannot attack if defeated

        Weapon npcWeapon = getEquippedWeapon();
        System.out.print(getName() + " attacks " + target.getName() + " with " + npcWeapon.getName() + "... ");

        // Check chance to hit
        if (random.nextDouble() <= npcWeapon.getChanceToHit()) {
            int damageDealt = npcWeapon.getDamage();
            System.out.println("Hit!");
            target.takeDamage(damageDealt);
        } else {
            System.out.println("Missed!");
        }
    }

    // Method to make NPC hostile if attacked (optional)
    public void becomeHostile() {
        if (this.status == NPCStatus.FRIENDLY) {
            System.out.println(getName() + " becomes hostile!");
            this.status = NPCStatus.HOSTILE;
            this.dialogue = "You shouldn't have done that!"; // Change dialogue
        }
    }

    public void makeFriendly() { // Could be used after battle sometimes
        this.status = NPCStatus.FRIENDLY;
        System.out.println(getName() + " is no longer hostile.");
    }

    @Override
    public void takeDamage(int damage) {
        super.takeDamage(damage); // Call Player's takeDamage
        if (getHp() <= 0) {
            System.out.println(getName() + " has been defeated!");
            // Optionally make them non-hostile or remove them from room in Game class
        } else if (isHostile()) {
            // Maybe change dialogue or behavior when hit but not defeated
        }
    }
}