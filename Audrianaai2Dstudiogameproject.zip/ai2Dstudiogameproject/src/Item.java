public class Item {
    private String name;
    private String description;
    private boolean obtainable = false; // Default to false unless set otherwise

    public Item(String name, String description) {
        this.name = name;
        this.description = description;
        this.obtainable = true; // Default constructor implies obtainable
    }

    public Item(String name, String description, boolean obtainable) {
        this.name = name;
        this.description = description;
        this.obtainable = obtainable;
    }

    public boolean canHas() { // Renamed for clarity: isObtainable() might be better
        return obtainable;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void use() {
        // Default use action
        System.out.println("You can't seem to use the " + name + " right now. Try equipping the item first.");
    }

    // Keep for potential future use, but maybe remove if unused
    public boolean canUseIn(String roomDescription) {
        return false; // Default implementation
    }
}