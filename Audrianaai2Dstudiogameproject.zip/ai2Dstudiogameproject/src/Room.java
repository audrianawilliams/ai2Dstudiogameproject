import java.util.ArrayList;
import java.util.List; // Use List interface
import java.util.Iterator; // For safe removal during iteration

public class Room {
    private String description = "";
    // private Item item = null; // Remove single item
    private ArrayList<Item> items = new ArrayList<>(); // Hold multiple items
    private ArrayList<NPC> npcs = new ArrayList<>(); // Hold multiple NPCs
    private ArrayList<String> exits;

    // --- Constructors ---
    // Original constructor (adapt if needed, maybe add empty lists)
    public Room(String description, Item item, ArrayList<String> exits) {
        this.description = description;
        if (item != null) {
            this.items.add(item); // Add the single item to the list
        }
        this.exits = exits;
    }

    // More flexible constructor
    public Room(String description, ArrayList<String> exits) {
        this.description = description;
        this.exits = exits;
        // items and npcs lists are initialized empty by default
    }


    // --- Item Management ---
    public void addItem(Item item) {
        if (item != null) {
            this.items.add(item);
        }
    }

    public void removeItem(Item item) {
        this.items.remove(item);
    }
    
    // Get item by name (case-insensitive)
    public Item getItemByName(String name) {
        for (Item item : items) {
            if (item.getName().equalsIgnoreCase(name)) {
                return item;
            }
        }
        return null;
    }

    public ArrayList<Item> getItems() { // Get all items
        return items;
    }

    // --- NPC Management ---
    public void addNPC(NPC npc) {
        if (npc != null) {
            this.npcs.add(npc);
        }
    }

    public void removeNPC(NPC npc) {
        this.npcs.remove(npc);
    }
    
    // Get NPC by name (case-insensitive)
    public NPC getNPCByName(String name) {
        for (NPC npc : npcs) {
            if (npc.getName().equalsIgnoreCase(name)) {
                return npc;
            }
        }
        return null;
    }


    public ArrayList<NPC> getNPCs() {
        return npcs;
    }
    // --- End New Methods ---

    // --- Updated Methods ---
    public String getDescription() {
        StringBuilder fullDescription = new StringBuilder(description); // Use StringBuilder for efficiency

         // List items in the room
         if (!items.isEmpty()) {
             fullDescription.append("\nYou see the following items: ");
             for (int i = 0; i < items.size(); i++) {
                 fullDescription.append(items.get(i).getName());
                 if (i < items.size() - 1) {
                     fullDescription.append(", ");
                 }
             }
             fullDescription.append(".");
         } else {
             // Keep original item description logic if needed, or remove if handled by listing
             // fullDescription.append("\nThere are no loose items here.");
         }


         // List NPCs in the room
         if (!npcs.isEmpty()) {
             fullDescription.append("\nAlso present: ");
             for (int i = 0; i < npcs.size(); i++) {
                 fullDescription.append(npcs.get(i).getName());
                  if (npcs.get(i).getHp() <= 0) {
                      fullDescription.append(" (defeated)");
                  }
                 if (i < npcs.size() - 1) {
                     fullDescription.append(", ");
                 }
             }
             fullDescription.append(".");
         }


        return fullDescription.toString();
    }

    // Deprecate? Or keep for compatibility? Prefer getItemByName
    public Item getItem() {
        if (!items.isEmpty()) {
            return items.get(0); // Return first item for old compatibility? Risky.
        }
        return null; // Better to return null if using old logic
    }


    public String getItemDesc() {
        if (items.isEmpty()) {
            return "nothing notable";
        }
        // Describe the first item for compatibility, or list all?
        return items.get(0).getDescription(); // Still potentially ambiguous
    }

    public ArrayList<String> getExits() {
        return exits;
    }

    // Keep old removeItem() for compatibility? No, remove specific item.
    // public void removeItem(){ items.clear(); } // This removes ALL items, dangerous.


    public boolean validMove(String move) {
        // Check standard directions
        if (exits.contains(move)) {
            return true;
        }
        // Allow aliases like n, s, e, w
        switch (move) {
            case "n": return exits.contains("north");
            case "s": return exits.contains("south");
            case "e": return exits.contains("east");
            case "w": return exits.contains("west");
            default: return false;
        }
    }
}