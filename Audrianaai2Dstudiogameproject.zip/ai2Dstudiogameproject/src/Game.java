import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random; // Needed for player attack rolls


public class Game {
    private Room[][] myMap = new Room[4][4];
    private int playerX = 0; // Current X
    private int playerY = 0; // Current Y
    private int prevPlayerX = 0; // Previous X (for fleeing)
    private int prevPlayerY = 0; // Previous Y (for fleeing)


    private Player player; // Player object
    private boolean winCondition = false; //tracks if the player has won the game
    private boolean bossDefeated = false;//tracks if boss is defeated
    private boolean vaultOpened = false; //checks if vault has been opened
    private boolean doorOpened = false; // checks if door has been opened
    private boolean inBattle = false; // Battle state flag
    private NPC currentOpponent = null; // Current NPC being fought
    private boolean playerTurn = true; // Whose turn is it in battle?
    private static final Random random = new Random(); // For player attack rolls




    public Game() {
        // --- Player Setup ---
        // Player(String name, String description, int initialHp)
        player = new Player("Robber", "You are a bank robber about to ROB A BANK. Find the vault in the basement and USE the KEY to unlock it. Be warned, you will face obstacles that will try to get in your way. Search rooms for useful items to add to your inventory. Good luck, and remember that each move needs to be a text command!", 20); // Player starts with 20 HP


        // --- Map Initialization ---
        initializeMap(); // Separate method for clarity


        // --- Set Start Location ---
        playerX = 1;
        playerY = 3;
        prevPlayerX = playerX;
        prevPlayerY = playerY;
    }


    private void initializeMap() {
        // Create Rooms (using new constructor)
        myMap[1][3] = new Room("This is the LOBBY: A medium-sized room where the front desk has illuminated letters. A grand chandelier hangs above from the ceiling and slowly flickers. There are small glass cubicles for offices surrounding, and some refreshments and snacks in the back of the room next to a mysterious looking archway.", new ArrayList<>(Arrays.asList("north", "east")));
        myMap[1][2] = new Room("You have entered the HALLWAY: Much less inviting than the lobby, with only a single flickering ceiling light, and dirty floors. You look for something to help with your plan...", new ArrayList<>(Arrays.asList("north", "south", "east")));
        myMap[1][1] = new Room("These are the DARK STAIRS:. Where they lead you do not know, but maybe they lead to what you have been searching for. You also see a large door on the side of the stairs hidden next to a landing on your right.", new ArrayList<>(Arrays.asList("north", "south", "east")));
        myMap[1][0] = new Room("You see a glowing VAULT with a large lock on it. There are no cameras or lasers, just one lock on the outside around the door. ", new ArrayList<>(Arrays.asList("south")));
        myMap[2][2] = new Room("The Supply Closet: The small room has tall shelves for storage. There are cleaning supplies, ladders, money rollers, and envelopes, but there is another thing you see.", new ArrayList<>(Arrays.asList("west")));
        myMap[2][1] = new Room("You have entered the SECURITY ROOM: There are a bunch of gadgets in here that may be useful. There is a screen displaying images of all of the rooms inside of the bank. There are monitors, laptops, and there is a bright florescent shining overhead. Behind you is a table full of lost and found. You see a keycard, an employee must have dropped it. Then, you turn around and a screen catches your eye. You notice something moving in one of the rooms. You are not alone... ", new ArrayList<>(Arrays.asList("west")));
        myMap[2][3] = new Room("Looks like you have entered an unusual looking break room. Chairs are scattered everywhere around a round table. You hear footsteps near you. You see a large looking door that unlocks with keycard access.", new ArrayList<>(Arrays.asList("east", "west")));
        myMap[3][3] = new Room("You've breached an ACCESS-ONLY area: You look around to try to find something that could help. Until you see what's in front of you... ", new ArrayList<>(Arrays.asList("north", "west")));
        myMap[3][2] = new Room("You walked through an exit door and you made it outside! You hear an engine running... hurry get in!!", new ArrayList<>(Arrays.asList("South")));


        //future me- figure out how to use the keycard to unlock the door. then add a npc in room 3,3. finally there should be an escape exit(no win)
        //in room 3,2. once that is done reassess the difficulty and clarity of the game. especially when it comes it using and equipping items.


        // Add Items
        myMap[2][1].addItem(new Item("keycard", "A simple, standard, rectangular card used by employees. Provides access to locked doors within the bank.")); // Keycard is an Item
        myMap[2][2].addItem(new Item("key", "A small, brass key. Looks important. Remember the plan.")); // Key is an Item
        myMap[1][0].addItem(new Item("vault", "A heavy steel vault door. It's locked.", false)); // Vault is an Item, not obtainable
        myMap[1][2].addItem(new Weapon("crowbar", "A sturdy crowbar. Might be useful against guards. When you want to use this weapon, make sure to equip it first.", 5, 0.80)); // Add a weapon
        myMap[2][3].addItem(new Item("Door", "A tall, steel door with no door handle. There is a a small glowing key terminal attached to the side of the wall near the door. And a sign in the middle of the door reads 'Employees Only: Do Not Enter'.", false)); // Door is an Item, not obtainable
        // myMap[3][2].addItem(new Item("getaway car","A black sports car with tinted windows.",true));
        myMap[2][3].addItem(new Weapon("Sword", " A golden, sparkling sword made for the toughest battles", 5, 0.90));
        //getaway car
        //crowbar should only be used to help fight guard. create a new weapon with more damage for the final boss
        // Add NPCs
        // NPC(String name, String description, int initialHp, NPCStatus status, String dialogue, Weapon weapon)
        NPC guard = new NPC("Guard", "A security guard pacing nervously.", 15, NPCStatus.HOSTILE, "Halt! You aren't supposed to be here!", new Weapon("Baton", "Standard issue security baton.", 3, 0.90));
        myMap[1][2].addNPC(guard); // Put the guard in the hallway


        NPC janitor = new NPC("Janitor", "An old janitor sweeping the floor.", 10, NPCStatus.FRIENDLY, "Just doing my job... don't mind me.", null); // Friendly, no weapon (uses fists)
        myMap[1][1].addNPC(janitor); // Put janitor on the stairs


        NPC boss = new NPC("Papa Rotzi", "Final Boss: A menacingly scary man swinging a bat who dedicates his life to protecting the access-only room.", 25, NPCStatus.HOSTILE, "Well, look what we have here! Come to Papa!", new Weapon("Bat", "A metal bat with pointy spikes.", 5, 0.60));
        myMap[3][3].addNPC(boss);//Put final boss in the access-only room


        NPC driver = new NPC("Driver", "A man waiting in the driver's seat of a black car.", 10, NPCStatus.FRIENDLY, "Get in loser, we're going shopping!!", null);//puts the getaway driver in the driver's seat of the car
        myMap[3][2].addNPC(driver);//put driver outside
        //create a new npc called getaway driver where you interact with him to get in the car
    }


    public void move(String input) {
        // Store previous location before moving
        prevPlayerX = playerX;
        prevPlayerY = playerY;


        String direction = input;
        // Handle shorthand inputs
        if (input.equals("n")) direction = "north";
        if (input.equals("s")) direction = "south";
        if (input.equals("e")) direction = "east";
        if (input.equals("w")) direction = "west";




        if (getCurrentRoom().validMove(direction)) {
            switch (direction) {
                case "north":
                    playerY -= 1;
                    break;
                case "south":
                    playerY += 1;
                    break;
                case "west":
                    playerX -= 1;
                    break;
                case "east":
                    playerX += 1;
                    break;
            }
            // Check for boundary issues (optional, depends on map design)
            // playerX = Math.max(0, Math.min(playerX, myMap.length - 1));
            // playerY = Math.max(0, Math.min(playerY, myMap[0].length - 1));


            // Print new room description after moving
            System.out.println("\n" + getCurrentRoom().getDescription());


        } else {
            System.out.println("You cannot go that way.");
            // Restore previous location if move was invalid (though validMove should prevent this call)
            playerX = prevPlayerX;
            playerY = prevPlayerY;
        }
    }


    // Helper to get the current room
    private Room getCurrentRoom() {
        // Add bounds checking for safety
        if (playerX >= 0 && playerX < myMap.length && playerY >= 0 && playerY < myMap[playerX].length) {
            return myMap[playerX][playerY];
        }
        // Handle error case - should not happen with valid moves, but good practice
        System.err.println("Error: Player is outside map bounds!");
        // Maybe return to start room or handle appropriately
        playerX = 1;
        playerY = 3; // Go back to start
        return myMap[playerX][playerY];
    }




    // --- Battle Methods ---
    private void startBattle(NPC opponent) {
        if (opponent == null || opponent.getHp() <= 0) {
            System.out.println("There's no one suitable to attack here.");
            return;
        }
        if (!opponent.isHostile()) {
            System.out.println(opponent.getName() + " doesn't want to fight you!");
            // Optional: Make friendly NPCs hostile if attacked
            // opponent.becomeHostile();
            // System.out.println("...but now they look angry!");
            return; // Don't start battle if friendly and not provoked
        }


        inBattle = true;
        currentOpponent = opponent;
        playerTurn = true; // Player always attacks first
        System.out.println("\n--- Battle Started with " + opponent.getName() + "! ---");
        displayBattleStatus();
        System.out.println("Commands: attack, flee");
    }


    private void handleBattleTurn(String input) {
        if (!inBattle || currentOpponent == null) return; // Safety check


        if (input.equals("attack")) {
            playerAttack();
            // Check if opponent defeated
            if (currentOpponent.getHp() <= 0) {
                endBattle(true); // Player wins
                return; // End turn processing
            }
            // If opponent survived, it's their turn
            playerTurn = false;


        } else if (input.equals("flee")) {
            fleeBattle();
            return; // End turn processing
        } else {
            System.out.println("Invalid battle command. Options: attack, flee");
            return; // Don't proceed to NPC turn if command was invalid
        }


        // --- NPC's Turn ---
        if (!playerTurn && inBattle) { // Check inBattle again in case flee happened
            System.out.println("\n" + currentOpponent.getName() + "'s turn:");
            currentOpponent.attack(player);
            // Check if player defeated
            if (player.getHp() <= 0) {
                endBattle(false); // Player loses
                return;
            }
            // It's player's turn again
            playerTurn = true;
            displayBattleStatus(); // Show status before player's next input
            System.out.print("Battle > "); // Prompt for next battle action
        }
    }


    private void playerAttack() {
        Weapon currentWeapon = player.getEquippedWeapon();
        System.out.print("\nYou attack " + currentOpponent.getName() + " with your " + currentWeapon.getName() + "... ");


        // Check chance to hit
        if (random.nextDouble() <= currentWeapon.getChanceToHit()) {
            int damageDealt = currentWeapon.getDamage();
            System.out.println("HIT!");
            currentOpponent.takeDamage(damageDealt);
        } else {
            System.out.println("MISSED!");
        }
    }




    private void fleeBattle() {
        System.out.println("You attempt to flee!");
        // Basic flee: always succeed and move to previous room
        inBattle = false;
        currentOpponent = null;
        playerX = prevPlayerX;
        playerY = prevPlayerY;
        System.out.println("You managed to escape back to the previous area.");
        System.out.println("\n" + getCurrentRoom().getDescription()); // Show description of room fled to
    }


    private void endBattle(boolean playerWon) {
        inBattle = false;
        if (playerWon) {
            System.out.println("\n--- Victory! You defeated " + currentOpponent.getName() + "! ---");


            // Check if player just defeated the boss
            if (currentOpponent.getName().equals("Papa Rotzi")) {
                this.bossDefeated = true;
                System.out.println("With the Papa Rotzi defeated, you can now escape with the money!");


                // If vault is already opened, set win condition
                  /* if (vaultOpened && doorOpened) {
                       winCondition = true;
                   }*/


            }


            //currentOpponent = null;
        } else {
            // Your existing defeat code
            System.out.println("\n--- Defeat! " + currentOpponent.getName() + " knocked you out! ---");
            //Game Over
            System.out.println("Your robbery attempt has failed. Game Over.");
            System.exit(0);// End the game on player defeat
        }
        currentOpponent = null;
    }




    private void displayBattleStatus() {
        if (!inBattle || currentOpponent == null) return;
        System.out.println("Your HP: " + player.getHp() + " | " + currentOpponent.getName() + " HP: " + currentOpponent.getHp());
    }




    // --- End Battle Methods ---




    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Game game = new Game();
        String input;


        // --- Change Welcome Message and Goal --- ADD MORE EMOJIS FOR THE HELP COMMANDS!!!
        System.out.println("Welcome to the Bank Heist!🥷💵🏦😃");
        System.out.println(game.player.getDescription()); // Show player's goal
        System.out.println("To begin the heist, type 'help' to see the list of commands.");
        System.out.println("HINT: To make your first move, go north");
        System.out.println("\n--- Current Location ---");
        System.out.println(game.getCurrentRoom().getDescription()); // Use helper method


       /*boolean winCondition = false; // Vault successfully opened
       boolean vaultOpened = false;   // Track if vault has been opened
       boolean doorOpened = false;    // Track if secured door has been opened
       boolean bossDefeated = false;*/// Track if FBI agent is defeated


        while (true) {
            if (game.inBattle) {
                // If in battle, prompt for battle command
                // Status might already be displayed at end of NPC turn
                // game.displayBattleStatus(); // Display status each turn if desired
                if (game.playerTurn) { // Only prompt if it's player's turn
                    System.out.print("Battle > ");
                }
                input = scanner.nextLine().toLowerCase().trim();
                game.handleBattleTurn(input); // Process battle command
                if (game.player.getHp() <= 0) { // Check if player lost after handling turn
                    System.out.println("Game Over!");
                    break; // Exit the main loop
                }
            } else {
                // --- Normal Gameplay ---
                System.out.print("> ");
                input = scanner.nextLine().toLowerCase().trim();

                 if (input.equals("look")) {
                    System.out.println(game.getCurrentRoom().getDescription()); // Shows room, items, NPCs
                    System.out.println("Exits: " + game.getCurrentRoom().getExits());
                } else if (input.equals("inventory") || input.equals("i")) {
                    if (game.player.getInventory().isEmpty()) {
                        System.out.println("Your inventory is empty.");
                    } else {
                        System.out.println("Your inventory contains:");
                        for (Item item : game.player.getInventory()) {
                            System.out.println("- " + item.getName() + ": " + item.getDescription());
                        }
                    }
                    System.out.println("Equipped Weapon: " + game.player.getEquippedWeapon().getName() + " (Damage: " + game.player.getEquippedWeapon().getDamage() + ")");
                } else if (input.equals("health") || input.equals("hp")) {
                    System.out.println("Your current HP: " + game.player.getHp());
                } else if (input.equals("help")) {
                    System.out.println("\n--- Available Commands ---");
                    System.out.println("-  To move to a new room: type (north, south, east, west (or n, s, e, w)");
                    System.out.println("- look: Examine the current room, items, NPCs, and exits. Hint: Confused? USE LOOK command🔎🔎");
                    System.out.println("- pick up [item name]: Take an item from the room🤌");
                    System.out.println("- inventory (or i): Check your items and equipped weapon");
                    System.out.println("- equip [weapon name]: Equip a weapon from your inventory");
                    System.out.println("- use [item name]: Use an item");
                    System.out.println("- use [item name] on [target name]: Use an item on something (e.g., 'use key on vault')");
                    System.out.println("- talk to [npc name]: Speak with someone🗣🗣");
                    System.out.println("- attack [npc name]: Start combat with someone🩸⚔️");
                    System.out.println("- health (or hp): Check your current health points🔋");
                    System.out.println("- help: Show this help message❓");
                    System.out.println("- quit: Exit the game❌");
                    System.out.println("\n--- Battle Commands (only during battle) ---");
                    System.out.println("- attack: Attack the opponent with your equipped weapon");
                    System.out.println("- flee: Attempt to escape the battle");
                }

                // Check for movement first
                if (input.equals("north") || input.equals("south") || input.equals("east") || input.equals("west") ||
                        input.equals("n") || input.equals("s") || input.equals("e") || input.equals("w")) {
                    game.move(input);
                }
                // --- Item Interaction ---
                else if (input.startsWith("pick up ")) {
                    String itemName = input.substring(8).trim();
                    Room currentRoom = game.getCurrentRoom();
                    Item itemToPick = currentRoom.getItemByName(itemName);
                    if (itemToPick != null) {
                        if (itemToPick.canHas()) {
                            game.player.pickUp(itemToPick); // Add to inventory
                            currentRoom.removeItem(itemToPick); // Remove from room
                            System.out.println("You picked up the " + itemToPick.getName() + ".");
                        } else {
                            System.out.println("You can't pick up the " + itemToPick.getName() + ".");
                        }
                    } else {
                        System.out.println("There is no '" + itemName + "' here to pick up.");
                    }
                } else if (input.startsWith("use ")) {
                    String combined = input.substring(4).trim();
                    String itemName = combined;
                    String targetName = null;


                    // Check for "use item on target" pattern
                    if (combined.contains(" on ")) {
                        String[] parts = combined.split(" on ", 2);
                        itemName = parts[0].trim();
                        targetName = parts[1].trim();
                    }


                    Item itemToUse = null;
                    for (Item item : game.player.getInventory()) {
                        if (item.getName().equalsIgnoreCase(itemName)) {
                            itemToUse = item;
                            break;
                        }
                    }
                    // use key on vault--
                    if (itemToUse.getName().equalsIgnoreCase("Key") &&
                            targetName != null && targetName.equalsIgnoreCase("Vault")) {
                        Room currentRoom = game.getCurrentRoom();
                        Item targetItem = currentRoom.getItemByName("Vault");
                        if (targetItem != null && targetItem.getName().equalsIgnoreCase("Vault")) {
                            System.out.println("You insert the key into the vault lock... CLICK!");
                            System.out.println("The heavy vault door swings open revealing millions of dollars of cash!!");
                            game.vaultOpened = true;  // Set vault opened flag


                            // Only set win condition if the player has completed the required tasks
                            if (game.bossDefeated && game.doorOpened) {
                                //winCondition = true;  // Complete game win
                                System.out.println("Now you just need to get to the getaway car!");
                            } else {
                                System.out.println("You still need to find a way out of the bank with the money!");
                            }
                        } else {
                            System.out.println("There is no vault here to use the key on.");
                        }
                    }



                    //----USE KEYCARD ON DOOR----
                    else if (itemToUse.getName().equalsIgnoreCase("keycard") &&
                            targetName != null && targetName.equalsIgnoreCase("door")) {
                        if (game.playerX == 2 && game.playerY == 3) { // Check if in break room [2][3]
                            Room roomWithDoorItem = game.myMap[2][3]; // Explicitly get the room where the "Door" item exists
                            Item doorItem = roomWithDoorItem.getItemByName("door");


                            if (doorItem != null && doorItem.getName().equalsIgnoreCase("door")) {
                                if (game.doorOpened) {
                                    System.out.println("The door is already open. You can type 'east' to go through.");
                                } else {
                                    System.out.println("The large door makes a loud whirring sound and BAM! The door slowly slides open for you to enter.");
                                    // This "A HUGE FBI agent..." line might be better as part of room [3][3]'s description or boss's intro dialogue.
                                    System.out.println("A HUGE FBI agent is standing in the middle of the room with a bat ready to swing at you.");
                                    game.doorOpened = true;


                                    game.prevPlayerX = game.playerX;
                                    game.prevPlayerY = game.playerY;


                                    game.playerX = 3;
                                    game.playerY = 3;


                                    Room bossRoom = game.getCurrentRoom(); // This is now room [3][3]
                                    System.out.println("\n--- You've entered the ACCESS-ONLY area ---"); // Or use bossRoom.getDescription()
                                    System.out.println(bossRoom.getDescription());




                                    NPC boss = bossRoom.getNPCByName("Papa Rotzi");
                                    if (boss != null && boss.getHp() > 0) {
                                        // Use boss's dialogue from NPC object if available and relevant
                                        System.out.println(boss.getName() + " snarls: \"" + boss.getDialogue() + "\"");
                                        game.startBattle(boss);
                                    } else if (boss != null && boss.getHp() <= 0) {
                                        System.out.println("Papa Rotzi is already defeated here.");
                                    } else {
                                        System.out.println("The room seems quiet... for now. (Error: Boss NPC not found as expected in [3][3])");
                                    }
                                }
                            } else {
                                System.out.println("There is no 'door' item here to use the keycard on.");
                            }
                        } else {
                            System.out.println("You need to be in the Break Room  to use the keycard on this door.");
                        }
                    }




                }


                // --- Weapon Equipping ---
                else if (input.startsWith("equip ")) {
                    String weaponName = input.substring(6).trim();
                    Weapon weaponToEquip = game.player.findWeaponInInventory(weaponName);
                    if (weaponToEquip != null) {
                        game.player.equipWeapon(weaponToEquip);
                    } else {
                        // Check if they are trying to equip fists explicitly or unequip
                        if (weaponName.equalsIgnoreCase("fists")) {
                            game.player.equipWeapon(null); // Equips default fists
                        } else {
                            System.out.println("You don't have a weapon named '" + weaponName + "' in your inventory.");
                        }
                    }
                }
                // --- NPC Interaction ---


                // --- NPC Interaction ---
                // SPECIFIC "talk to driver" MUST COME BEFORE GENERAL "talk to"
                if (input.startsWith("talk to ") && input.substring(8).trim().equalsIgnoreCase("driver")) {
                    if (game.playerX == 3 && game.playerY == 2) { // Player must be in driver's room
                        Room currentRoom = game.getCurrentRoom();
                        NPC driverNpc = currentRoom.getNPCByName("Driver");


                        if (driverNpc != null) {
                            // Check for winning conditions using game object's flags
                            if (game.vaultOpened && game.doorOpened && game.bossDefeated) {
                                // Use driver's stored dialogue
                                System.out.println(driverNpc.getName() + ": \"" + driverNpc.getDialogue() + "\""); // "Get in loser, we're going shopping!!"
                                System.out.println("You jump into the getaway car with the money!");
                                System.out.println("The driver floors it and you speed away from the bank!");
                                game.winCondition = true; // Set the Game object's win condition flag
                            } else if (!game.vaultOpened) {
                                System.out.println("'Where's the money?' the driver asks...");
                            } else { // This covers (!game.doorOpened || !game.bossDefeated)
                                System.out.println("'Did you take care of everyone who saw you?' the driver asks nervously.");
                            }
                        } else {
                            System.out.println("The driver isn't here. Are you in the right spot ([3][2])?");
                        }
                    } else {
                        System.out.println("You need to be at the exit ([3][2]) to talk to the driver.");
                    }
                    if (input.startsWith("talk to ")) {
                        String npcName = input.substring(8).trim();
                        Room currentRoom = game.getCurrentRoom();
                        NPC npc = currentRoom.getNPCByName(npcName);
                        if (npc != null) {
                            if (npc.getHp() > 0) { // Can only talk to conscious NPCs
                                npc.talk();
                            } else {
                                System.out.println(npc.getName() + " is defeated and cannot talk.");
                            }
                        } else {
                            System.out.println("There is no one named '" + npcName + "' here.");
                        }
                    } else if (input.startsWith("attack ")) {
                        String npcName = input.substring(7).trim();
                        Room currentRoom = game.getCurrentRoom();
                        NPC npcToAttack = currentRoom.getNPCByName(npcName);
                        if (npcToAttack != null) {
                            if (npcToAttack.getHp() > 0) {
                                game.startBattle(npcToAttack);
                                // Battle loop takes over, so don't print room desc again here
                            } else {
                                System.out.println(npcToAttack.getName() + " is already defeated.");
                            }
                        } else {
                            System.out.println("There is no one named '" + npcName + "' here to attack.");
                        }


                    }


                    // --- Other Commands ---
                    else if (input.equals("look")) {
                        System.out.println(game.getCurrentRoom().getDescription()); // Shows room, items, NPCs
                        System.out.println("Exits: " + game.getCurrentRoom().getExits());
                    } else if (input.equals("inventory") || input.equals("i")) {
                        if (game.player.getInventory().isEmpty()) {
                            System.out.println("Your inventory is empty.");
                        } else {
                            System.out.println("Your inventory contains:");
                            for (Item item : game.player.getInventory()) {
                                System.out.println("- " + item.getName() + ": " + item.getDescription());
                            }
                        }
                        System.out.println("Equipped Weapon: " + game.player.getEquippedWeapon().getName() + " (Damage: " + game.player.getEquippedWeapon().getDamage() + ")");
                    } else if (input.equals("health") || input.equals("hp")) {
                        System.out.println("Your current HP: " + game.player.getHp());
                    } else if (input.equals("help")) {
                        System.out.println("\n--- Available Commands ---");
                        System.out.println("-  To move to a new room: type (north, south, east, west (or n, s, e, w)");
                        System.out.println("- look: Examine the current room, items, NPCs, and exits. Hint: Confused? USE LOOK command🔎🔎");
                        System.out.println("- pick up [item name]: Take an item from the room🤌");
                        System.out.println("- inventory (or i): Check your items and equipped weapon");
                        System.out.println("- equip [weapon name]: Equip a weapon from your inventory");
                        System.out.println("- use [item name]: Use an item");
                        System.out.println("- use [item name] on [target name]: Use an item on something (e.g., 'use key on vault')");
                        System.out.println("- talk to [npc name]: Speak with someone🗣🗣");
                        System.out.println("- attack [npc name]: Start combat with someone🩸⚔️");
                        System.out.println("- health (or hp): Check your current health points🔋");
                        System.out.println("- help: Show this help message❓");
                        System.out.println("- quit: Exit the game❌");
                        System.out.println("\n--- Battle Commands (only during battle) ---");
                        System.out.println("- attack: Attack the opponent with your equipped weapon");
                        System.out.println("- flee: Attempt to escape the battle");



                    } else if (input.equals("quit")) {
                        System.out.println("Thanks for playing!");
                        break;
                    } else {
                        // Only print invalid if not a move attempt (which gives its own message)
                        if (!Arrays.asList("north", "south", "east", "west", "n", "s", "e", "w").contains(input)) {
                            System.out.println("Invalid command. Type 'help' for a list of commands.");
                        }
                    }
                } // End of normal gameplay vs battle block


                // Check win condition after processing input
                if (game.winCondition) {
                    System.out.println("\n*** Congratulations! You successfully robbed the bank! Same time tomorrow? ***");
                    System.out.println("Thanks for playing!");
                    break; // Exit the main loop
                }


                // Check player health after any action (outside battle loop check)
                if (!game.inBattle && game.player.getHp() <= 0) {
                    System.out.println("You succumbed to your injuries outside of battle. Game Over. :( ");
                    break; // Exit loop if player somehow reached 0 HP outside combat
                }




            } // End main game loop (while true)
        }


        // Close the scanner
        scanner.close();
    }
}







