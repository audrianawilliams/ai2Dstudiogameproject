import java.util.ArrayList;

public class Player {
    private ArrayList<Item> inventory = new ArrayList<>();
    private String name = "Player"; // Give the player a default name
    private String description = "";
    private int hp; // Add Health Points
    private Weapon equippedWeapon; // Add equipped weapon

    // Constructor updated
    public Player(String name, String description, int initialHp) {
        this.name = name;
        this.description = description;
        this.hp = initialHp;
        // Equip default fists
        this.equippedWeapon = new Weapon("Fists", "Your own bare hands.", 1, 1.0); // Default weapon
    }

    // --- New Methods ---
    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = Math.max(0, hp); // Ensure HP doesn't go below 0
    }

    public void takeDamage(int damage) {
        this.hp -= damage;
        if (this.hp < 0) {
            this.hp = 0;
        }
        System.out.println(this.name + " takes " + damage + " damage. Remaining HP: " + this.hp);
    }

    public Weapon getEquippedWeapon() {
        return equippedWeapon;
    }

    public void equipWeapon(Weapon weapon) {
        if (weapon != null) {
            this.equippedWeapon = weapon;
            System.out.println("You equipped " + weapon.getName() + ".");
        } else {
             // Equip fists if null weapon is passed (e.g., unequipping)
             this.equippedWeapon = new Weapon("Fists", "Your own bare hands.", 1, 1.0);
             System.out.println("You equipped your Fists.");
        }
    }

    // Find a weapon in inventory by name (case-insensitive)
    public Weapon findWeaponInInventory(String weaponName) {
         for (Item item : inventory) {
             if (item instanceof Weapon && item.getName().equalsIgnoreCase(weaponName)) {
                 return (Weapon) item;
             }
         }
         return null;
     }
    // --- End New Methods ---


    // Pick up specific item
    public void pickUp(Item item) {
        if (item != null && item.canHas()) { // Check if item exists and is obtainable
             inventory.add(item);
             // Don't remove from room here, Game class should handle that
        }
    }
    // Method to remove an item (e.g., after equipping, though we won't do that here)
    public void removeItemFromInventory(Item item) {
        inventory.remove(item);
    }


    public void setName(String name) { // Added setter for name if needed later
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return description;
    }

    public ArrayList<Item> getInventory() {
        return inventory;
    }

    // Overload for original pickup logic if needed elsewhere, but prefer specific item pickup
     public void pickUp(Room room){
         Item itemToPick = room.getItem(); // Assumes old single-item logic
         if (itemToPick != null && itemToPick.canHas()) {
             inventory.add(itemToPick);
             room.removeItem(itemToPick); // Remove the specific item
         }
     }
}